﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseBetting
{
    class Horse
    {
        // I create a Horse class which stores the following details of the horse race such as name, date, bet amount and bet status indicator
        public string Name { get; set; }
        public string Dte { get; set; }
        public double Amount { get; set; }
        public bool Status { get; set; }


        // Initialiaze the empty constructor
        public Horse()

        { }


        // Populate the constructor with properties
        public Horse(string name, string dte, double amount, bool status)
        {


            Name = name;
            Dte = dte;
            Amount = amount;
            Status = status;


        }

        public override string ToString()
        {
            return ($"The name is:  {Name} \nThe date  is:  {Dte} \nThe amount is:  {Amount}\n and the bet status is {Status}");
        }


    }
}
 
