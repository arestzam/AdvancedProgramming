﻿using HorseBetting;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseBetting
{
    class Program
    {
       
        public class ReadTextFileEx3
        {

            static void Main(string[] args)

            {

                // Now I will read the binary data from the file I have created and will output on the console


                FileStream fs = new FileStream(@"R:\RaceData.CSV", FileMode.Open,
                        FileAccess.Read);

                using (StreamReader streamReader = new StreamReader(fs, Encoding.UTF8))
                {
                    string line = String.Empty;

                    while ((line = streamReader.ReadLine()) != null)
                    {
                        // Outputs the binary file to the console
                        Console.WriteLine(line);
                    }

                }

                Console.ReadLine();


            }

    


// Here is first way to read a binary file into a byte type array
public class FileArray
{
    public static void Array(Stream stream, byte[] data)
    {
        int offset = 0;
        int remaining = data.Length;
        while (remaining > 0)
        {
            int read = stream.Read(data, offset, remaining);
            if (read <= 0)
                throw new EndOfStreamException
                    (String.Format("End of stream reached with {0} bytes left to read", remaining));
            remaining -= read;
            offset += read;
        }
    }
}


        }
    }
}


// I HAVE TRIED TO WRITE UP LINQ QUERIES TO RETURN RESULTS BUT I HAVE SYNTAX ERRORS FOR ALL SUCH QUEIRIES SO i COMMENTED THE SOURCE CODE IN ORDER FOR THE REST CODE TO RUN


/* START OF LINQ QUERIES

IEnumerable<int> SortbyDate =
   from date in data
   orderby Dte
   select num;


var SortByDate = data.OrderByDescending(s => s.Dte);


//Here is the LINq query to order data by AmountWon as defined with var

    var orderByResult = from s in data
                orderby s.Amount
                select new { s.Amount };


// The first LINQ query will output the years, total won and total lost



var totalwon = from c in data
           where c == true;




// Here is the LINq query to sum up the data by Amount


IEnumerable<int> SumUp =
   from num in data
   orderby Dte
   select num;





var totalwon2 = HorseData.Sum(x => x.Amount);

    
// A report that show the highest amount won and the most lost for a bet


var highestamount = (from c in data
                     where data.Max(c => c.Amount);
Console.WriteLine("The data by the highest amount won are the following");


var lowestamount = (from c in data.Amount
                    where data.Min(c => c.Amount);

Console.WriteLine("The data by the lowest amount won are the following:");



//**********************************************************************************************************
//END OF LINQ QUERIES


 /* Here is another way to read binary file into an array
public class ByteArray
{
    public byte[] Array(string fileName)
    {
        byte[] buff = null;
        FileStream fs = new FileStream(fileName,
                                       FileMode.Open,
                                       FileAccess.Read);
        BinaryReader br = new BinaryReader(fs);
        long numBytes = new FileInfo(fileName).Length;
        buff = br.ReadBytes((int)numBytes);
        // return the Array
        return File.ReadAllBytes(fileName);
    }

}

   
Another way to Read a CSV file in to an array 



var lineCount = File.ReadLines(@"C:\file.txt").Count();
var reader = new StreamReader(File.OpenRead(@"C:\location1.csv"));
int[,] properties = new int[lineCount,4];
for(int i2 = 0; i2 < 4; i2++)
{
for(int i = 0; i < lineCount; i++)
{
var line = reader.ReadLine();
var values = line.Split(';');
properties[i,i2] = Convert.ToInt32(values[i2];


How to read a file using REgular Exression?

        var table = new List <string]();
        using (var r = new streamReader("filepath name")

{ while (!r.EndofStream)
{ string line = r.ReadLine();
table.Add(Regex.Split(line @\s\[;]/[;]");


    }
r.close();


*********************************************************************************************************
*/















