﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorseBetting
{
    class HorseList
    {

        //I have hard coded the data into a new list as follows but THIS CODE IS NOT INCLUDED in the project
        // Please DISREGARD this part as I have NOT IMPLEMENTED INTO THE running code


        List<Horse> HorseData = new List<Horse>() {
                new Horse() { Name = "Aintree",  Dte = "2017,05,12", Amount = 11.58, Status= true},
                new Horse() { Name = "Punchestown", Dte = "2016,12,22", Amount = 122.52, Status=true } ,
                new Horse() { Name = "Sanddown", Dte = "2016,11,17", Amount =20.00, Status=false } ,
                new Horse() { Name = "Ayr", Dte = "2016,11,03", Amount=25.00, Status=false} ,
                new Horse() { Name = "FairyHouse" , Dte = "2016,12,02", Amount= 65.75, Status=true},


                new Horse() { Name = "Ayr",  Dte = "2017,05,12", Amount = 12.05, Status= true},
                new Horse() { Name = "Doncaster", Dte = "2016,03,12", Amount = 10.00, Status=false } ,
                new Horse() { Name = "Towncester", Dte = "2016,03,12", Amount =50.00, Status=false } ,
                new Horse() { Name = "Goodwood", Dte = "2017,10,07", Amount=525.74, Status=true} ,
                new Horse() { Name = "Kelso" , Dte = "2016,09,13", Amount= 43.21, Status=true},


                new Horse() { Name = "Punchestown",  Dte = "2017,05,12", Amount = 35.00, Status= false},
                new Horse() { Name = "Ascot", Dte = "2016,02,04", Amount = 23.65, Status=true} ,
                new Horse() { Name = "Kelso", Dte = "2017,08,02", Amount =30.00, Status=false} ,
                new Horse() { Name = "Towcester", Dte = "2017,07,05", Amount=104.33, Status=true} ,
                new Horse() { Name = "Ascot" , Dte = "2017,06,21", Amount= 25.00, Status=false},


                new Horse() { Name = "Bangor",  Dte = "2016,22,12", Amount = 30.00, Status= false},
                new Horse() { Name = "Ayr", Dte = "2017,05,22", Amount = 11.50, Status=true} ,
                new Horse() { Name = "Ascot", Dte = "2017,06,23", Amount =30.00, Status=false } ,
                new Horse() { Name = "Ascot", Dte = "2017,06,23", Amount=374.27, Status=true} ,
                new Horse() { Name = "Goodwood" , Dte = "2016,10,05", Amount= 34.12, Status=true},



                new Horse() { Name = "Dundalk",  Dte = "2016,11,09", Amount = 20.00, Status= false},
                new Horse() { Name = "Haydock", Dte = "2016,11,12", Amount = 87.00, Status=true } ,
                new Horse() { Name = "Perth", Dte = "2017,01,20", Amount =15.00, Status=false } ,
                new Horse() { Name = "York", Dte = "2017,11,11", Amount=101.25, Status=true} ,
                new Horse() { Name = "Punchstown" , Dte = "2016,12,22", Amount= 11.50, Status=true},


                new Horse() { Name = "Chester",  Dte = "2016,08,14", Amount = 10.00, Status= false},
                new Horse() { Name = "Kelso", Dte = "2016,09,18", Amount = 10.00, Status=false} ,
                new Horse() { Name = "Kilbeggan", Dte = "2017,03,03", Amount =20.00, Status=false } ,
                new Horse() { Name = "FairyHouse", Dte = "2017,03,11", Amount=55.50, Status=true} ,
                new Horse() { Name = "Punchestown" , Dte = "2016,11,15", Amount= 10.00, Status=false},



                new Horse() { Name = "Towcester",  Dte = "2016,05,08", Amount = 16.55, Status= true},
                new Horse() { Name = "Punchestown", Dte = "2016,05,23", Amount = 13.71, Status=true } ,
                new Horse() { Name = "Cork", Dte = "2016,11,30", Amount =20.00, Status=false } ,
                new Horse() { Name = "Punchestown", Dte = "2016,04,25", Amount=13.45, Status=true} ,
                new Horse() { Name = "Bangor" , Dte = "2016,01,23", Amount= 10.00, Status=false},

                new Horse() { Name = "Sandown" , Dte = "2017,08,07", Amount= 25.00, Status=false}

                            };


       

    }
}
